#ifndef MPU6050_H
#define MPU6050_H
#include <stdint.h>
#include "esp_err.h"

typedef struct {
    int sda_gpio;
    int scl_gpio;
    uint8_t i2c_addr;
    uint32_t i2c_freq_hz;
} mpu6050_config_t;

typedef struct {
    int16_t ax, ay, az, gx, gy, gz;
} mpu6050_sample_t;

esp_err_t mpu6050_i2c_init(const mpu6050_config_t *cfg);
esp_err_t mpu6050_init(void);
esp_err_t mpu6050_wake(void);
esp_err_t mpu6050_configure_100hz_2g_250dps(void);
esp_err_t mpu6050_fifo_enable(void);
esp_err_t mpu6050_fifo_disable(void);
esp_err_t mpu6050_fifo_reset(void);
esp_err_t mpu6050_fifo_count(uint16_t *count);
esp_err_t mpu6050_read_fifo_samples(mpu6050_sample_t *samples, uint16_t requested, uint32_t timeout_ms, uint16_t *read_samples);
esp_err_t mpu6050_clear_interrupts(void);
esp_err_t mpu6050_sleep(void);
#endif
