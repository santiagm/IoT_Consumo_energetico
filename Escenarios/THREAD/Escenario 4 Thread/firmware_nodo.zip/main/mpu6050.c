#include "mpu6050.h"

#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "driver/i2c_master.h"

#include "esp_log.h"
#include "esp_check.h"

static const char *TAG = "mpu6050";

static i2c_master_bus_handle_t s_bus = NULL;
static i2c_master_dev_handle_t s_dev = NULL;
static uint8_t s_addr = 0x69;

#define REG_SMPLRT_DIV      0x19
#define REG_CONFIG          0x1A
#define REG_GYRO_CONFIG     0x1B
#define REG_ACCEL_CONFIG    0x1C
#define REG_FIFO_EN         0x23
#define REG_INT_STATUS      0x3A
#define REG_USER_CTRL       0x6A
#define REG_PWR_MGMT_1      0x6B
#define REG_PWR_MGMT_2      0x6C
#define REG_FIFO_COUNTH     0x72
#define REG_FIFO_R_W        0x74
#define REG_WHO_AM_I        0x75

#define MPU_I2C_TIMEOUT_MS          300
#define MPU_I2C_RETRIES             5
#define MPU_FIFO_SAMPLE_BYTES       12
#define MPU_FIFO_SETTLE_MS          20
#define MPU_FIFO_READ_RETRY_MS      5

static esp_err_t wr_once(uint8_t reg, uint8_t val)
{
    uint8_t data[2] = {reg, val};
    return i2c_master_transmit(
        s_dev,
        data,
        sizeof(data),
        pdMS_TO_TICKS(MPU_I2C_TIMEOUT_MS)
    );
}

static esp_err_t rd_once(uint8_t reg, uint8_t *data, size_t len)
{
    return i2c_master_transmit_receive(
        s_dev,
        &reg,
        1,
        data,
        len,
        pdMS_TO_TICKS(MPU_I2C_TIMEOUT_MS)
    );
}

static esp_err_t wr(uint8_t reg, uint8_t val)
{
    esp_err_t ret = ESP_FAIL;

    for (int i = 1; i <= MPU_I2C_RETRIES; i++) {
        ret = wr_once(reg, val);

        if (ret == ESP_OK) {
            return ESP_OK;
        }

        ESP_LOGW(
            TAG,
            "wr reg=0x%02X val=0x%02X fallo intento %d/%d: %s",
            reg,
            val,
            i,
            MPU_I2C_RETRIES,
            esp_err_to_name(ret)
        );

        vTaskDelay(pdMS_TO_TICKS(MPU_FIFO_READ_RETRY_MS));
    }

    return ret;
}

static esp_err_t rd(uint8_t reg, uint8_t *data, size_t len)
{
    esp_err_t ret = ESP_FAIL;

    for (int i = 1; i <= MPU_I2C_RETRIES; i++) {
        ret = rd_once(reg, data, len);

        if (ret == ESP_OK) {
            return ESP_OK;
        }

        ESP_LOGW(
            TAG,
            "rd reg=0x%02X len=%u fallo intento %d/%d: %s",
            reg,
            (unsigned)len,
            i,
            MPU_I2C_RETRIES,
            esp_err_to_name(ret)
        );

        vTaskDelay(pdMS_TO_TICKS(MPU_FIFO_READ_RETRY_MS));
    }

    return ret;
}

esp_err_t mpu6050_i2c_init(const mpu6050_config_t *cfg)
{
    if (!cfg) {
        return ESP_ERR_INVALID_ARG;
    }

    s_addr = cfg->i2c_addr;

    if (!s_bus) {
        i2c_master_bus_config_t bus_cfg = {
            .i2c_port = I2C_NUM_0,
            .sda_io_num = cfg->sda_gpio,
            .scl_io_num = cfg->scl_gpio,
            .clk_source = I2C_CLK_SRC_DEFAULT,
            .glitch_ignore_cnt = 7,
            .flags.enable_internal_pullup = true,
        };

        ESP_RETURN_ON_ERROR(
            i2c_new_master_bus(&bus_cfg, &s_bus),
            TAG,
            "bus init"
        );
    }

    if (!s_dev) {
        i2c_device_config_t dev_cfg = {
            .dev_addr_length = I2C_ADDR_BIT_LEN_7,
            .device_address = s_addr,
            .scl_speed_hz = cfg->i2c_freq_hz,
        };

        ESP_RETURN_ON_ERROR(
            i2c_master_bus_add_device(s_bus, &dev_cfg, &s_dev),
            TAG,
            "add dev"
        );
    }

    return ESP_OK;
}

esp_err_t mpu6050_wake(void)
{
    ESP_RETURN_ON_ERROR(wr(REG_PWR_MGMT_1, 0x01), TAG, "wake pwr1");

    vTaskDelay(pdMS_TO_TICKS(20));

    ESP_RETURN_ON_ERROR(wr(REG_PWR_MGMT_2, 0x00), TAG, "wake pwr2");

    vTaskDelay(pdMS_TO_TICKS(50));

    return ESP_OK;
}

esp_err_t mpu6050_configure_100hz_2g_250dps(void)
{
    ESP_RETURN_ON_ERROR(wr(REG_CONFIG, 0x03), TAG, "dlpf");

    /*
     * Con DLPF activo, el gyro base suele quedar en 1 kHz.
     * SMPLRT_DIV = 9 -> 100 Hz.
     * Cada muestra completa FIFO = 12 bytes:
     * ax ay az gx gy gz.
     */
    ESP_RETURN_ON_ERROR(wr(REG_SMPLRT_DIV, 9), TAG, "sample 100Hz");

    ESP_RETURN_ON_ERROR(wr(REG_ACCEL_CONFIG, 0x00), TAG, "acc 2g");
    ESP_RETURN_ON_ERROR(wr(REG_GYRO_CONFIG, 0x00), TAG, "gyro 250");

    vTaskDelay(pdMS_TO_TICKS(10));

    return ESP_OK;
}

esp_err_t mpu6050_init(void)
{
    uint8_t who = 0;

    ESP_RETURN_ON_ERROR(mpu6050_wake(), TAG, "wake init");

    ESP_RETURN_ON_ERROR(rd(REG_WHO_AM_I, &who, 1), TAG, "whoami");

    if ((who & 0x7E) != 0x68) {
        ESP_LOGW(
            TAG,
            "WHO_AM_I inesperado=0x%02X; continuo por si es clon GY-521",
            who
        );
    } else {
        ESP_LOGI(TAG, "WHO_AM_I OK=0x%02X", who);
    }

    return mpu6050_configure_100hz_2g_250dps();
}

esp_err_t mpu6050_fifo_disable(void)
{
    ESP_RETURN_ON_ERROR(wr(REG_FIFO_EN, 0x00), TAG, "fifo en off");
    vTaskDelay(pdMS_TO_TICKS(MPU_FIFO_SETTLE_MS));
    return ESP_OK;
}

esp_err_t mpu6050_fifo_enable(void)
{
    /*
     * FIFO_EN = 0x78:
     * TEMP_FIFO_EN = 0
     * XG_FIFO_EN   = 1
     * YG_FIFO_EN   = 1
     * ZG_FIFO_EN   = 1
     * ACCEL_FIFO_EN= 1
     */
    ESP_RETURN_ON_ERROR(wr(REG_FIFO_EN, 0x78), TAG, "fifo en on");
    vTaskDelay(pdMS_TO_TICKS(MPU_FIFO_SETTLE_MS));
    return ESP_OK;
}

esp_err_t mpu6050_fifo_reset(void)
{
    /*
     * Secuencia más segura:
     * 1. Desactivar fuentes FIFO.
     * 2. Desactivar USER_CTRL.
     * 3. Reset FIFO.
     * 4. Activar FIFO.
     */
    ESP_RETURN_ON_ERROR(wr(REG_FIFO_EN, 0x00), TAG, "fifo disable before reset");
    vTaskDelay(pdMS_TO_TICKS(5));

    ESP_RETURN_ON_ERROR(wr(REG_USER_CTRL, 0x00), TAG, "user ctrl off");
    vTaskDelay(pdMS_TO_TICKS(5));

    ESP_RETURN_ON_ERROR(wr(REG_USER_CTRL, 0x04), TAG, "fifo reset");
    vTaskDelay(pdMS_TO_TICKS(10));

    ESP_RETURN_ON_ERROR(wr(REG_USER_CTRL, 0x40), TAG, "fifo master enable");
    vTaskDelay(pdMS_TO_TICKS(10));

    return ESP_OK;
}

esp_err_t mpu6050_fifo_count(uint16_t *count)
{
    if (!count) {
        return ESP_ERR_INVALID_ARG;
    }

    uint8_t b[2] = {0};

    ESP_RETURN_ON_ERROR(rd(REG_FIFO_COUNTH, b, 2), TAG, "fifo count");

    *count = ((uint16_t)b[0] << 8) | b[1];

    return ESP_OK;
}

static esp_err_t wait_fifo_bytes(uint16_t needed_bytes, uint32_t timeout_ms)
{
    TickType_t start = xTaskGetTickCount();

    while (((xTaskGetTickCount() - start) * portTICK_PERIOD_MS) < timeout_ms) {
        uint16_t count = 0;

        esp_err_t ret = mpu6050_fifo_count(&count);

        if (ret == ESP_OK) {
            if (count >= needed_bytes) {
                ESP_LOGI(TAG, "FIFO lista: count=%u needed=%u", count, needed_bytes);
                return ESP_OK;
            }
        } else {
            ESP_LOGW(TAG, "fifo_count esperando fallo: %s", esp_err_to_name(ret));
        }

        vTaskDelay(pdMS_TO_TICKS(10));
    }

    uint16_t final_count = 0;
    mpu6050_fifo_count(&final_count);

    ESP_LOGE(
        TAG,
        "Timeout esperando FIFO: count=%u needed=%u",
        final_count,
        needed_bytes
    );

    return ESP_ERR_TIMEOUT;
}

static esp_err_t read_one_fifo_sample(mpu6050_sample_t *sample)
{
    if (!sample) {
        return ESP_ERR_INVALID_ARG;
    }

    uint8_t raw[MPU_FIFO_SAMPLE_BYTES] = {0};
    esp_err_t ret = ESP_FAIL;

    for (int intento = 1; intento <= MPU_I2C_RETRIES; intento++) {
        uint16_t count = 0;

        ret = mpu6050_fifo_count(&count);

        if (ret != ESP_OK) {
            ESP_LOGW(
                TAG,
                "No se pudo leer FIFO_COUNT antes de muestra intento %d/%d: %s",
                intento,
                MPU_I2C_RETRIES,
                esp_err_to_name(ret)
            );

            vTaskDelay(pdMS_TO_TICKS(MPU_FIFO_READ_RETRY_MS));
            continue;
        }

        if (count < MPU_FIFO_SAMPLE_BYTES) {
            ESP_LOGW(
                TAG,
                "FIFO con pocos bytes antes de muestra: count=%u intento=%d/%d",
                count,
                intento,
                MPU_I2C_RETRIES
            );

            vTaskDelay(pdMS_TO_TICKS(10));
            continue;
        }

        ret = rd(REG_FIFO_R_W, raw, sizeof(raw));

        if (ret == ESP_OK) {
            sample->ax = (int16_t)((raw[0] << 8) | raw[1]);
            sample->ay = (int16_t)((raw[2] << 8) | raw[3]);
            sample->az = (int16_t)((raw[4] << 8) | raw[5]);
            sample->gx = (int16_t)((raw[6] << 8) | raw[7]);
            sample->gy = (int16_t)((raw[8] << 8) | raw[9]);
            sample->gz = (int16_t)((raw[10] << 8) | raw[11]);

            return ESP_OK;
        }

        ESP_LOGW(
            TAG,
            "Lectura FIFO_R_W fallo intento %d/%d: %s",
            intento,
            MPU_I2C_RETRIES,
            esp_err_to_name(ret)
        );

        vTaskDelay(pdMS_TO_TICKS(MPU_FIFO_READ_RETRY_MS));
    }

    return ret;
}

esp_err_t mpu6050_read_fifo_samples(
    mpu6050_sample_t *samples,
    uint16_t requested,
    uint32_t timeout_ms,
    uint16_t *read_samples
)
{
    if (!samples || !read_samples || requested == 0) {
        return ESP_ERR_INVALID_ARG;
    }

    *read_samples = 0;

    const uint16_t needed_bytes = requested * MPU_FIFO_SAMPLE_BYTES;

    ESP_RETURN_ON_ERROR(
        wait_fifo_bytes(needed_bytes, timeout_ms),
        TAG,
        "wait fifo bytes"
    );

    for (uint16_t i = 0; i < requested; i++) {
        esp_err_t ret = read_one_fifo_sample(&samples[i]);

        if (ret != ESP_OK) {
            ESP_LOGE(
                TAG,
                "Fallo leyendo muestra FIFO %u/%u, read_samples=%u: %s",
                i + 1,
                requested,
                *read_samples,
                esp_err_to_name(ret)
            );

            return ret;
        }

        (*read_samples)++;
    }

    if (*read_samples != requested) {
        ESP_LOGE(
            TAG,
            "FIFO incompleta: read_samples=%u requested=%u",
            *read_samples,
            requested
        );

        return ESP_ERR_INVALID_SIZE;
    }

    return ESP_OK;
}

esp_err_t mpu6050_clear_interrupts(void)
{
    uint8_t dummy = 0;
    return rd(REG_INT_STATUS, &dummy, 1);
}

esp_err_t mpu6050_sleep(void)
{
    /*
     * Se apaga ordenadamente la FIFO antes de dormir el MPU6050.
     */
    mpu6050_fifo_disable();

    wr(REG_USER_CTRL, 0x00);

    vTaskDelay(pdMS_TO_TICKS(20));

    ESP_RETURN_ON_ERROR(wr(REG_PWR_MGMT_1, 0x40), TAG, "sleep");

    vTaskDelay(pdMS_TO_TICKS(20));

    return ESP_OK;
}