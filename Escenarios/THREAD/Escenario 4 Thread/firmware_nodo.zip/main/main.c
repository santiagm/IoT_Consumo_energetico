#include <stdio.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"
#include "esp_sleep.h"
#include "esp_timer.h"
#include "nvs_flash.h"
#include "esp_mac.h"

#include "driver/gpio.h"

#include "config.h"
#include "mpu6050.h"
#include "telemetry_packet.h"
#include "thread_packet.h"
#include "crypto_helper.h"
#include "thread_sender.h"

static const char *TAG = "nodo_thread";

RTC_DATA_ATTR static uint16_t rtc_batch_id = 0;

static void fill_src_id(char out[18])
{
    uint8_t mac[6] = {0};

    esp_read_mac(mac, ESP_MAC_WIFI_STA);

    snprintf(
        out,
        18,
        "%02X:%02X:%02X:%02X:%02X:%02X",
        mac[0],
        mac[1],
        mac[2],
        mac[3],
        mac[4],
        mac[5]
    );
}

static void release_gpios(void)
{
    /*
     * IMPORTANTE:
     * En ESP32-C6 no todos los GPIO son RTC GPIO.
     * Por eso NO usamos rtc_gpio_deinit() aquí.
     * Eso era lo que producía:
     * RTCIO: rtc_gpio_deinit(65): RTCIO number error
     */
    for (size_t i = 0; i < NODE_GPIOS_TO_RELEASE_COUNT; ++i) {
        gpio_num_t gpio = NODE_GPIOS_TO_RELEASE[i];

        gpio_reset_pin(gpio);
        gpio_set_direction(gpio, GPIO_MODE_DISABLE);
        gpio_pullup_dis(gpio);
        gpio_pulldown_dis(gpio);
    }
}

static void deep_sleep_now(void)
{
#if NODE_ENABLE_RTC_PERIODIC_WAKEUP
    ESP_ERROR_CHECK(
        esp_sleep_enable_timer_wakeup(
            (uint64_t)NODE_WAKEUP_PERIOD_SEC * 1000000ULL
        )
    );
#endif

    release_gpios();

    ESP_LOGI(TAG, "Entrando en deep sleep");

    esp_deep_sleep_start();
}

static esp_err_t init_nvs(void)
{
    esp_err_t ret = nvs_flash_init();

    if (ret == ESP_ERR_NVS_NO_FREE_PAGES ||
        ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }

    return ret;
}

static esp_err_t read_mpu6050_batch(sensor_packet_t *pkt)
{
    if (!pkt) {
        return ESP_ERR_INVALID_ARG;
    }

    esp_err_t ret = ESP_FAIL;

    mpu6050_config_t cfg = {
        .sda_gpio = I2C_SDA_GPIO,
        .scl_gpio = I2C_SCL_GPIO,
        .i2c_addr = MPU_I2C_ADDR,
        .i2c_freq_hz = I2C_MASTER_FREQ_HZ
    };

    ESP_LOGI(
        TAG,
        "Inicializando MPU6050 SDA=%d SCL=%d ADDR=0x%02X FREQ=%lu",
        I2C_SDA_GPIO,
        I2C_SCL_GPIO,
        MPU_I2C_ADDR,
        (unsigned long)I2C_MASTER_FREQ_HZ
    );

    ret = mpu6050_i2c_init(&cfg);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "mpu6050_i2c_init fallo: %s", esp_err_to_name(ret));
        return ret;
    }

    /*
     * Después de deep sleep, el MPU6050 puede necesitar tiempo para estabilizarse.
     * Reducido de 300ms a 100ms manteniendo margen de seguridad.
     */
    vTaskDelay(pdMS_TO_TICKS(100));

    /*
     * Reintentos de inicialización.
     * Esto evita fallos intermitentes tipo:
     * mpu6050_wake(...): pwr2
     * mpu6050_init fallo: ESP_ERR_INVALID_RESPONSE
     */
    for (int intento = 1; intento <= 5; intento++) {
        ESP_LOGI(TAG, "Intento init MPU6050 %d/5", intento);

        ret = mpu6050_init();

        if (ret == ESP_OK) {
            ESP_LOGI(TAG, "MPU6050 inicializado correctamente");
            break;
        }

        ESP_LOGW(
            TAG,
            "mpu6050_init fallo intento %d: %s",
            intento,
            esp_err_to_name(ret)
        );

        vTaskDelay(pdMS_TO_TICKS(300));
    }

    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "mpu6050_init fallo final: %s", esp_err_to_name(ret));
        return ret;
    }

    ret = mpu6050_fifo_disable();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "mpu6050_fifo_disable fallo: %s", esp_err_to_name(ret));
        return ret;
    }

    vTaskDelay(pdMS_TO_TICKS(50));

    ret = mpu6050_fifo_reset();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "mpu6050_fifo_reset fallo: %s", esp_err_to_name(ret));
        return ret;
    }

    vTaskDelay(pdMS_TO_TICKS(50));

    ret = mpu6050_fifo_enable();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "mpu6050_fifo_enable fallo: %s", esp_err_to_name(ret));
        return ret;
    }

    /*
     * Este delay es para llenar la FIFO con el número de muestras configurado.
     * Se calcula automáticamente basado en STREAM_SAMPLE_COUNT y MPU_SAMPLE_RATE_HZ.
     * Con STREAM_SAMPLE_COUNT=5 y MPU_SAMPLE_RATE_HZ=100: 50ms + 30ms margen = 80ms
     */
    vTaskDelay(pdMS_TO_TICKS(MPU_FIFO_FILL_TIME_MS));

    mpu6050_sample_t raw[STREAM_SAMPLE_COUNT] = {0};
    uint16_t read_n = 0;

    ESP_LOGI(
        TAG,
        "Leyendo FIFO MPU6050: muestras esperadas=%d timeout=%d ms",
        STREAM_SAMPLE_COUNT,
        MPU_FIFO_TIMEOUT_MS
    );

    ret = mpu6050_read_fifo_samples(
        raw,
        STREAM_SAMPLE_COUNT,
        MPU_FIFO_TIMEOUT_MS,
        &read_n
    );

    if (ret != ESP_OK) {
        ESP_LOGE(
            TAG,
            "mpu6050_read_fifo_samples fallo: %s read_n=%u",
            esp_err_to_name(ret),
            read_n
        );

        mpu6050_fifo_disable();
        mpu6050_fifo_reset();
        mpu6050_sleep();

        return ret;
    }

    ESP_LOGI(TAG, "MPU6050 FIFO OK, muestras leidas=%u", read_n);

    if (read_n == 0) {
        ESP_LOGE(TAG, "MPU6050 FIFO sin muestras");
        return ESP_FAIL;
    }

    if (read_n != STREAM_SAMPLE_COUNT) {
        ESP_LOGE(
            TAG,
            "FIFO incompleta: se esperaban %d muestras, se leyeron %u. No se envia paquete.",
            STREAM_SAMPLE_COUNT,
            read_n
        );

        mpu6050_fifo_disable();
        mpu6050_fifo_reset();
        mpu6050_sleep();

        return ESP_ERR_INVALID_SIZE;
    }

    for (int i = 0; i < STREAM_SAMPLE_COUNT; ++i) {
        pkt->muestras[i].ax = raw[i].ax;
        pkt->muestras[i].ay = raw[i].ay;
        pkt->muestras[i].az = raw[i].az;
        pkt->muestras[i].gx = raw[i].gx;
        pkt->muestras[i].gy = raw[i].gy;
        pkt->muestras[i].gz = raw[i].gz;
    }

    ESP_LOGI(
        TAG,
        "Primera muestra MPU: ax=%d ay=%d az=%d gx=%d gy=%d gz=%d",
        pkt->muestras[0].ax,
        pkt->muestras[0].ay,
        pkt->muestras[0].az,
        pkt->muestras[0].gx,
        pkt->muestras[0].gy,
        pkt->muestras[0].gz
    );

    return ESP_OK;
}

void app_main(void)
{
    int64_t t0 = esp_timer_get_time();
    int64_t t_stage = 0;

    esp_sleep_wakeup_cause_t causa = esp_sleep_get_wakeup_cause();

#if NODE_DEBUG_LOGS
    ESP_LOGI(TAG, "Wakeup cause=%d", causa);

    if (causa == ESP_SLEEP_WAKEUP_TIMER) {
        ESP_LOGI(TAG, "Desperto por TIMER RTC");
    } else if (causa == ESP_SLEEP_WAKEUP_UNDEFINED) {
        ESP_LOGW(TAG, "Arranque normal o reset, NO fue wakeup por deep sleep timer");
    } else {
        ESP_LOGW(TAG, "Otra causa de wakeup=%d", causa);
    }
#endif

    esp_err_t ret = init_nvs();

    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "NVS init fallo: %s", esp_err_to_name(ret));
        vTaskDelay(pdMS_TO_TICKS(2000));
        deep_sleep_now();
    }

    sensor_packet_t pkt = {0};

    fill_src_id(pkt.src_mac);

    pkt.start_timestamp_ms = (uint32_t)(esp_timer_get_time() / 1000ULL);
    pkt.batch_id = ++rtc_batch_id;

#if NODE_DEBUG_LOGS
    ESP_LOGI(
        TAG,
        "Nodo Thread inicio batch=%u src=%s",
        pkt.batch_id,
        pkt.src_mac
    );
#endif

    /*
     * Primero leemos MPU6050.
     * Si falla, NO intentamos Thread todavía.
     * Se deja log claro y dormimos para volver a intentar.
     */
    t_stage = esp_timer_get_time();
    ret = read_mpu6050_batch(&pkt);
    int64_t t_mpu_ms = (esp_timer_get_time() - t_stage) / 1000;

    if (ret != ESP_OK) {
        ESP_LOGE(
            TAG,
            "No se pudo leer MPU6050. No se envia paquete. ret=%s tiempo_mpu_ms=%lld",
            esp_err_to_name(ret),
            t_mpu_ms
        );

        vTaskDelay(pdMS_TO_TICKS(1000));
        deep_sleep_now();
    }

    thread_app_packet_t tp = {0};

    tp.magic = THREAD_PACKET_MAGIC;
    tp.version = THREAD_PACKET_VERSION;
    tp.batch_id = pkt.batch_id;

    size_t enc_len = 0;

    t_stage = esp_timer_get_time();
    ret = crypto_encrypt_payload(
        (const uint8_t *)&pkt,
        sizeof(pkt),
        pkt.batch_id,
        pkt.src_mac,
        tp.iv,
        tp.encrypted_payload,
        sizeof(tp.encrypted_payload),
        &enc_len,
        tp.auth_tag
    );
    int64_t t_crypto_ms = (esp_timer_get_time() - t_stage) / 1000;

    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "crypto_encrypt_payload fallo: %s tiempo_crypto_ms=%lld", esp_err_to_name(ret), t_crypto_ms);
        vTaskDelay(pdMS_TO_TICKS(1000));
        deep_sleep_now();
    }

    tp.encrypted_len = (uint16_t)enc_len;

#if NODE_DEBUG_LOGS
    ESP_LOGI(
        TAG,
        "Payload cifrado OK batch=%u encrypted_len=%u tiempo_crypto_ms=%lld",
        tp.batch_id,
        tp.encrypted_len,
        t_crypto_ms
    );
#endif

    t_stage = esp_timer_get_time();
    //vTaskDelay(pdMS_TO_TICKS(100));
    ret = thread_sender_init();
    int64_t t_thread_init_ms = (esp_timer_get_time() - t_stage) / 1000;

    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "thread_sender_init fallo: %s tiempo_thread_init_ms=%lld", esp_err_to_name(ret), t_thread_init_ms);
        vTaskDelay(pdMS_TO_TICKS(1000));
        deep_sleep_now();
    }

    t_stage = esp_timer_get_time();
    ret = thread_sender_send_packet(&tp);
    int64_t t_thread_send_ms = (esp_timer_get_time() - t_stage) / 1000;

    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "thread_sender_send_packet fallo: %s tiempo_thread_send_ms=%lld", esp_err_to_name(ret), t_thread_send_ms);
    } else {
#if NODE_DEBUG_LOGS
        ESP_LOGI(TAG, "Paquete Thread enviado OK batch=%u tiempo_thread_send_ms=%lld", tp.batch_id, t_thread_send_ms);
#endif
    }

    int64_t t_total_ms = (esp_timer_get_time() - t0) / 1000;
    
    ESP_LOGI(
        TAG,
        "batch=%u ret=%s activo_ms=%lld [mpu_ms=%lld crypto_ms=%lld thread_init_ms=%lld thread_send_ms=%lld]",
        pkt.batch_id,
        esp_err_to_name(ret),
        t_total_ms,
        t_mpu_ms,
        t_crypto_ms,
        t_thread_init_ms,
        t_thread_send_ms
    );

    /*
     * Margen post-envio Thread.
     * ret=ESP_OK solo indica que OpenThread acepto el paquete,
     * no garantiza que el gateway ya lo recibio/proceso.
     * Reducido de 500ms a 200ms para optimizar tiempo activo.
     */
    ESP_LOGI(TAG, "Esperando margen post-envio Thread antes de dormir");
    vTaskDelay(pdMS_TO_TICKS(10));

    mpu6050_fifo_disable();
    mpu6050_fifo_reset();
    mpu6050_sleep();

    vTaskDelay(pdMS_TO_TICKS(10));

    deep_sleep_now();
}