#include "telemetry_json.h"
#include <stdio.h>
#include "config.h"

esp_err_t telemetry_json_build(const sensor_packet_t *pkt, char *out, size_t out_len)
{
    if (!pkt || !out || out_len == 0) return ESP_ERR_INVALID_ARG;
    const mpu_sample_t *s = &pkt->muestras[0];
    float ax = s->ax / MPU_ACCEL_LSB_PER_G;
    float ay = s->ay / MPU_ACCEL_LSB_PER_G;
    float az = s->az / MPU_ACCEL_LSB_PER_G;
    float gx = s->gx / MPU_GYRO_LSB_PER_DPS;
    float gy = s->gy / MPU_GYRO_LSB_PER_DPS;
    float gz = s->gz / MPU_GYRO_LSB_PER_DPS;
    int n = snprintf(out, out_len,
        "{\"src_mac\":\"%s\",\"node_start_timestamp_ms\":%lu,\"batch_id\":%u,"
        "\"accel_x_g\":%.5f,\"accel_y_g\":%.5f,\"accel_z_g\":%.5f,"
        "\"gyro_x_dps\":%.5f,\"gyro_y_dps\":%.5f,\"gyro_z_dps\":%.5f}",
        pkt->src_mac, (unsigned long)pkt->start_timestamp_ms, pkt->batch_id,
        ax, ay, az, gx, gy, gz);
    return (n > 0 && (size_t)n < out_len) ? ESP_OK : ESP_ERR_NO_MEM;
}
