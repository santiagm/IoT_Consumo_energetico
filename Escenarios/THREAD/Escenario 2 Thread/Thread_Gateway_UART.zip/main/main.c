#include <stdbool.h>
#include <string.h>
#include <inttypes.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_err.h"
#include "esp_log.h"
#include "esp_system.h"
#include "nvs_flash.h"

#include "config.h"
#include "thread_packet.h"
#include "telemetry_packet.h"
#include "thread_receiver.h"
#include "telemetry_json.h"
#include "uart_bridge_sender.h"

static const char *TAG = "GW_THREAD_UART";

static uint16_t s_last_batch_id = 0;
static bool s_have_last_batch = false;

static uint32_t s_packets_received = 0;
static uint32_t s_packets_uart = 0;
static uint32_t s_packets_duplicates = 0;
static uint32_t s_packets_invalid = 0;
static uint32_t s_uart_errors = 0;

static esp_err_t gateway_nvs_init(void)
{
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    return ret;
}

static bool is_duplicate_batch(uint16_t batch_id)
{
    if (s_have_last_batch && s_last_batch_id == batch_id) {
        return true;
    }
    s_last_batch_id = batch_id;
    s_have_last_batch = true;
    return false;
}

static bool validate_thread_packet(const thread_app_packet_t *packet)
{
    if (packet == NULL) {
        return false;
    }

    if (packet->magic != THREAD_PACKET_MAGIC) {
        ESP_LOGW(TAG, "Magic invalido: 0x%04X", packet->magic);
        return false;
    }

    if (packet->version != THREAD_PACKET_VERSION) {
        ESP_LOGW(TAG, "Version invalida: %u", packet->version);
        return false;
    }

    if (packet->payload_len != sizeof(sensor_packet_t)) {
        ESP_LOGW(TAG, "payload_len invalido: %u esperado=%u",
                 packet->payload_len, (unsigned)sizeof(sensor_packet_t));
        return false;
    }

    return true;
}

static void log_metrics(void)
{
    ESP_LOGI(TAG,
             "Metricas RX=%" PRIu32 " UART=%" PRIu32 " DUP=%" PRIu32
             " INV=%" PRIu32 " UART_ERR=%" PRIu32,
             s_packets_received,
             s_packets_uart,
             s_packets_duplicates,
             s_packets_invalid,
             s_uart_errors);
}

static void handle_thread_packet(const thread_app_packet_t *packet, void *ctx)
{
    (void)ctx;
    s_packets_received++;

    if (!validate_thread_packet(packet)) {
        s_packets_invalid++;
        log_metrics();
        return;
    }

    ESP_LOGI(TAG, "Paquete Thread valido recibido. batch_id=%u", packet->batch_id);

    if (is_duplicate_batch(packet->batch_id)) {
        s_packets_duplicates++;
        ESP_LOGW(TAG, "Duplicado Thread ignorado. batch_id=%u", packet->batch_id);
        log_metrics();
        return;
    }

    sensor_packet_t sensor_packet = {0};
    memcpy(&sensor_packet, &packet->payload, sizeof(sensor_packet_t));

    esp_err_t ret = ESP_OK;

    if (sensor_packet.batch_id != packet->batch_id) {
        ESP_LOGW(TAG, "batch_id no coincide: header=%u payload=%u",
                 packet->batch_id, sensor_packet.batch_id);
    }

    char json[512];
    ret = telemetry_json_build(&sensor_packet, json, sizeof(json));
    if (ret != ESP_OK) {
        s_packets_invalid++;
        ESP_LOGE(TAG, "No se pudo construir JSON. batch_id=%u", packet->batch_id);
        log_metrics();
        return;
    }

    ESP_LOGI(TAG, "JSON generado: %s", json);

    ret = uart_bridge_send_json_line(json);
    if (ret != ESP_OK) {
        s_uart_errors++;
        ESP_LOGE(TAG, "Error enviando JSON por UART batch=%u", packet->batch_id);
        log_metrics();
        return;
    }

    s_packets_uart++;
    ESP_LOGI(TAG, "JSON enviado a Gateway MQTT por UART batch=%u", packet->batch_id);
    log_metrics();
}

void app_main(void)
{
    ESP_LOGI(TAG, "Iniciando Thread Gateway UART");

    ESP_ERROR_CHECK(gateway_nvs_init());
    ESP_ERROR_CHECK(uart_bridge_sender_init());

    ESP_LOGI(TAG, "Iniciando receptor Thread/OpenThread...");
    esp_err_t thread_ret = thread_receiver_init();

    if (thread_ret != ESP_OK) {
        ESP_LOGE(TAG, "Thread no se adjunto a tiempo. Reiniciando en 5 segundos...");
        vTaskDelay(pdMS_TO_TICKS(5000));
        esp_restart();
    }

    ESP_ERROR_CHECK(thread_receiver_start(handle_thread_packet, NULL));

    ESP_LOGI(TAG, "Thread Gateway listo. UDP Thread=%d UART TX=%d RX=%d baud=%d",
             THREAD_UDP_PORT, UART_BRIDGE_TX_GPIO, UART_BRIDGE_RX_GPIO, UART_BRIDGE_BAUD);

    while (true) {
        vTaskDelay(pdMS_TO_TICKS(10000));
        log_metrics();
    }
}
