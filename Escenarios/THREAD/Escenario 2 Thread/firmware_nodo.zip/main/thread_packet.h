#ifndef THREAD_PACKET_H
#define THREAD_PACKET_H

#include <stdint.h>
#include "config.h"
#include "telemetry_packet.h"

#define THREAD_PACKET_MAGIC      0x5448
#define THREAD_PACKET_VERSION    1

typedef struct __attribute__((packed)) {
    uint16_t magic;
    uint8_t version;
    uint16_t batch_id;
    uint16_t payload_len;
    sensor_packet_t payload;
} thread_app_packet_t;

#endif
