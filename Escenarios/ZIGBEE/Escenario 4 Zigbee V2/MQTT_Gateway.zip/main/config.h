#pragma once

#include "driver/gpio.h"
#include "driver/uart.h"

#define WIFI_SSID              "diqueerespobre"
#define WIFI_PASS              "soypobre"

#define THINGSBOARD_HOST       "mqtt.thingsboard.cloud"
#define THINGSBOARD_PORT       1883


#define THINGSBOARD_TOKEN      "Wj2rLAd4xKoOlPpuN0u7"

#define MQTT_TOPIC             "v1/devices/me/telemetry"

/* UART entre Zigbee Gateway y MQTT Gateway */
#define UART_PORT_NUM          UART_NUM_1
#define UART_TX_GPIO           GPIO_NUM_4
#define UART_RX_GPIO           GPIO_NUM_5
#define UART_BAUD_RATE         115200

/* Buffers grandes porque el JSON de Zigbee con 10 muestras mide ~680 bytes */
#define UART_RX_BUF_SIZE       4096
#define JSON_LINE_MAX_LEN      4096
#define MQTT_PAYLOAD_MAX_LEN   4096

/*
 * Alias para compatibilidad con archivos anteriores.
 * Esto evita errores porque uart_json_receiver.c usaba estos nombres.
 */
#define UART_BRIDGE_PORT       UART_PORT_NUM
#define UART_BRIDGE_TX_GPIO    UART_TX_GPIO
#define UART_BRIDGE_RX_GPIO    UART_RX_GPIO
#define UART_BRIDGE_BAUD       UART_BAUD_RATE
#define UART_JSON_MAX_LEN      JSON_LINE_MAX_LEN