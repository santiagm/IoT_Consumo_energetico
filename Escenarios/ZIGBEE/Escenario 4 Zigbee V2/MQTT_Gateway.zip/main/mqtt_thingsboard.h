#pragma once

#include <stdbool.h>
#include "esp_err.h"

esp_err_t mqtt_thingsboard_start(void);
bool mqtt_thingsboard_is_connected(void);
esp_err_t mqtt_thingsboard_publish_json(const char *json);