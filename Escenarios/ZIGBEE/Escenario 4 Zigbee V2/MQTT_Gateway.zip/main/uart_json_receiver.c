#include "uart_json_receiver.h"
#include "config.h"

#include <stdlib.h>
#include <string.h>

#include "esp_log.h"
#include "driver/uart.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "cJSON.h"

static const char *TAG = "UART_JSON";

static uart_json_cb_t s_cb = NULL;

static void process_json_line(char *line, int len)
{
    if (line == NULL || len <= 0) {
        return;
    }

    line[len] = '\0';

    cJSON *root = cJSON_Parse(line);
    if (root == NULL) {
        ESP_LOGE(TAG, "JSON_ERR parse len=%d", len);
        ESP_LOGE(TAG, "Linea recibida: %s", line);
        return;
    }

    cJSON_Delete(root);

    ESP_LOGI(TAG, "JSON recibido por UART len=%d", len);

    if (s_cb) {
        s_cb(line);
    }
}

static void uart_task(void *arg)
{
    (void)arg;

    char *line = calloc(1, JSON_LINE_MAX_LEN);
    if (line == NULL) {
        ESP_LOGE(TAG, "No hay memoria para buffer UART JSON");
        vTaskDelete(NULL);
        return;
    }

    int pos = 0;
    int brace_depth = 0;
    bool receiving_json = false;

    while (1) {
        uint8_t ch = 0;

        int n = uart_read_bytes(
            UART_PORT_NUM,
            &ch,
            1,
            pdMS_TO_TICKS(100)
        );

        if (n <= 0) {
            continue;
        }

        if (ch == '{') {
            if (!receiving_json) {
                pos = 0;
                brace_depth = 0;
                receiving_json = true;
            }
            brace_depth++;
        }

        if (receiving_json) {
            if (pos < JSON_LINE_MAX_LEN - 1) {
                line[pos++] = (char)ch;
            } else {
                ESP_LOGE(TAG,
                         "JSON_ERR linea supera buffer %d",
                         JSON_LINE_MAX_LEN);
                pos = 0;
                brace_depth = 0;
                receiving_json = false;
                continue;
            }
        }

        if (ch == '}') {
            if (receiving_json && brace_depth > 0) {
                brace_depth--;
            }

            if (receiving_json && brace_depth == 0) {
                process_json_line(line, pos);
                pos = 0;
                receiving_json = false;
            }
        }

        /*
         * Compatibilidad: si el Zigbee Gateway manda '\n',
         * también cerramos la línea aquí.
         */
        if ((ch == '\n' || ch == '\r') && receiving_json && pos > 0) {
            process_json_line(line, pos);
            pos = 0;
            brace_depth = 0;
            receiving_json = false;
        }
    }
}

esp_err_t uart_json_receiver_start(uart_json_cb_t cb)
{
    s_cb = cb;

    uart_config_t cfg = {
        .baud_rate = UART_BAUD_RATE,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };

    ESP_ERROR_CHECK(uart_driver_install(
        UART_PORT_NUM,
        UART_RX_BUF_SIZE,
        0,
        0,
        NULL,
        0
    ));

    ESP_ERROR_CHECK(uart_param_config(UART_PORT_NUM, &cfg));

    ESP_ERROR_CHECK(uart_set_pin(
        UART_PORT_NUM,
        UART_TX_GPIO,
        UART_RX_GPIO,
        UART_PIN_NO_CHANGE,
        UART_PIN_NO_CHANGE
    ));

    ESP_LOGI(TAG,
             "UART RX listo UART1 RX=%d TX=%d baud=%d",
             UART_RX_GPIO,
             UART_TX_GPIO,
             UART_BAUD_RATE);

    xTaskCreate(
        uart_task,
        "uart_json_rx",
        6144,
        NULL,
        5,
        NULL
    );

    return ESP_OK;
}