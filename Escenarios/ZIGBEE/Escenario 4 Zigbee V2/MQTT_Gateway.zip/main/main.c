#include <stdlib.h>
#include <string.h>

#include "esp_log.h"
#include "nvs_flash.h"
#include "cJSON.h"

#include "wifi_manager.h"
#include "mqtt_thingsboard.h"
#include "uart_json_receiver.h"

static const char *TAG = "MQTT_GATEWAY_UART";

static bool get_first_number_from_array(cJSON *array, double *out_value)
{
    if (!array || !out_value || !cJSON_IsArray(array)) {
        return false;
    }

    cJSON *item = cJSON_GetArrayItem(array, 0);

    if (!item || !cJSON_IsNumber(item)) {
        return false;
    }

    *out_value = item->valuedouble;
    return true;
}

static char *build_thingsboard_payload_sample0(const char *json_in)
{
    if (json_in == NULL) {
        return NULL;
    }

    cJSON *root = cJSON_Parse(json_in);

    if (root == NULL) {
        ESP_LOGE(TAG, "No se pudo parsear JSON recibido desde Zigbee Gateway");
        return NULL;
    }

    cJSON *src_mac_item = cJSON_GetObjectItem(root, "src_mac");
    cJSON *batch_id_item = cJSON_GetObjectItem(root, "batch_id");
    cJSON *timestamp_item = cJSON_GetObjectItem(root, "timestamp_ms");

    cJSON *accel_x_array = cJSON_GetObjectItem(root, "accel_x_g");
    cJSON *accel_y_array = cJSON_GetObjectItem(root, "accel_y_g");
    cJSON *accel_z_array = cJSON_GetObjectItem(root, "accel_z_g");

    cJSON *gyro_x_array = cJSON_GetObjectItem(root, "gyro_x_dps");
    cJSON *gyro_y_array = cJSON_GetObjectItem(root, "gyro_y_dps");
    cJSON *gyro_z_array = cJSON_GetObjectItem(root, "gyro_z_dps");

    if (!cJSON_IsString(src_mac_item) ||
        !cJSON_IsNumber(batch_id_item) ||
        !cJSON_IsNumber(timestamp_item)) {
        ESP_LOGE(TAG, "JSON recibido no tiene src_mac, batch_id o timestamp_ms valido");
        cJSON_Delete(root);
        return NULL;
    }

    double accel_x_g = 0.0;
    double accel_y_g = 0.0;
    double accel_z_g = 0.0;

    double gyro_x_dps = 0.0;
    double gyro_y_dps = 0.0;
    double gyro_z_dps = 0.0;

    if (!get_first_number_from_array(accel_x_array, &accel_x_g) ||
        !get_first_number_from_array(accel_y_array, &accel_y_g) ||
        !get_first_number_from_array(accel_z_array, &accel_z_g) ||
        !get_first_number_from_array(gyro_x_array, &gyro_x_dps) ||
        !get_first_number_from_array(gyro_y_array, &gyro_y_dps) ||
        !get_first_number_from_array(gyro_z_array, &gyro_z_dps)) {
        ESP_LOGE(TAG, "No se pudo obtener la muestra 0 de los arrays");
        cJSON_Delete(root);
        return NULL;
    }

    /*
     * ThingsBoard asigna la hora actual de llegada SOLO cuando el payload MQTT
     * es un JSON plano de telemetria. Si se envia {"values": {...}} sin un ts
     * Epoch real, ThingsBoard guarda "values" como una sola clave.
     *
     * Por eso aqui se publica una sola muestra, pero PARAMETRO POR PARAMETRO:
     * {
     *   "src_mac": "...",
     *   "node_start_timestamp_ms": 123,
     *   "batch_id": 1,
     *   "accel_x_g": ...,
     *   ...
     * }
     */
    cJSON *out = cJSON_CreateObject();

    if (out == NULL) {
        cJSON_Delete(root);
        return NULL;
    }

    cJSON_AddStringToObject(out, "src_mac", src_mac_item->valuestring);
    cJSON_AddNumberToObject(out, "node_start_timestamp_ms", timestamp_item->valuedouble);
    cJSON_AddNumberToObject(out, "batch_id", batch_id_item->valueint);

    cJSON_AddNumberToObject(out, "accel_x_g", accel_x_g);
    cJSON_AddNumberToObject(out, "accel_y_g", accel_y_g);
    cJSON_AddNumberToObject(out, "accel_z_g", accel_z_g);

    cJSON_AddNumberToObject(out, "gyro_x_dps", gyro_x_dps);
    cJSON_AddNumberToObject(out, "gyro_y_dps", gyro_y_dps);
    cJSON_AddNumberToObject(out, "gyro_z_dps", gyro_z_dps);

    char *payload = cJSON_PrintUnformatted(out);

    if (payload) {
        ESP_LOGI(TAG, "Payload ThingsBoard plano muestra 0 generado: %s", payload);
    }

    cJSON_Delete(out);
    cJSON_Delete(root);

    return payload;
}

static void on_json(const char *json)
{
    char *tb_payload = build_thingsboard_payload_sample0(json);

    if (tb_payload == NULL) {
        ESP_LOGE(TAG, "No se pudo construir payload ThingsBoard con muestra 0");
        return;
    }

    ESP_LOGI(TAG, "Publicando 1 mensaje MQTT con muestra 0");

    esp_err_t err = mqtt_thingsboard_publish_json(tb_payload);

    if (err != ESP_OK) {
        ESP_LOGW(TAG, "No se pudo publicar todavia, err=0x%x", err);
    }

    free(tb_payload);
}

void app_main(void)
{
    ESP_LOGI(TAG, "Iniciando MQTT Gateway UART");

    esp_err_t err = nvs_flash_init();

    if (err == ESP_ERR_NVS_NO_FREE_PAGES ||
        err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    } else {
        ESP_ERROR_CHECK(err);
    }

    ESP_ERROR_CHECK(wifi_manager_start());
    ESP_ERROR_CHECK(mqtt_thingsboard_start());
    ESP_ERROR_CHECK(uart_json_receiver_start(on_json));
}