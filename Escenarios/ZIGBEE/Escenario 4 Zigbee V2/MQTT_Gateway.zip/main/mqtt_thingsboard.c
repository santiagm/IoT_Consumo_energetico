#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#include "esp_log.h"
#include "esp_err.h"
#include "mqtt_client.h"

#include "config.h"
#include "mqtt_thingsboard.h"

static const char *TAG = "MQTT";

#define MQTT_TOPIC "v1/devices/me/telemetry"

static esp_mqtt_client_handle_t s_client = NULL;
static bool s_connected = false;

static void mqtt_event_handler(void *handler_args,
                               esp_event_base_t base,
                               int32_t event_id,
                               void *event_data)
{
    (void)handler_args;
    (void)base;

    esp_mqtt_event_handle_t event = (esp_mqtt_event_handle_t)event_data;

    switch ((esp_mqtt_event_id_t)event_id) {
    case MQTT_EVENT_CONNECTED:
        s_connected = true;
        ESP_LOGI(TAG, "MQTT conectado a ThingsBoard");
        break;

    case MQTT_EVENT_DISCONNECTED:
        s_connected = false;
        ESP_LOGW(TAG, "MQTT desconectado");
        break;

    case MQTT_EVENT_ERROR:
        ESP_LOGE(TAG, "MQTT connect failed");
        break;

    case MQTT_EVENT_PUBLISHED:
        ESP_LOGI(TAG, "MQTT publicado msg_id=%d", event->msg_id);
        break;

    default:
        break;
    }
}

esp_err_t mqtt_thingsboard_start(void)
{
    char uri[128];

    snprintf(uri, sizeof(uri), "mqtt://%s:%d", THINGSBOARD_HOST, THINGSBOARD_PORT);

    esp_mqtt_client_config_t mqtt_cfg = {
        .broker.address.uri = uri,
        .credentials.username = THINGSBOARD_TOKEN,
    };

    s_client = esp_mqtt_client_init(&mqtt_cfg);

    if (s_client == NULL) {
        ESP_LOGE(TAG, "No se pudo crear cliente MQTT");
        return ESP_FAIL;
    }

    ESP_ERROR_CHECK(esp_mqtt_client_register_event(
        s_client,
        ESP_EVENT_ANY_ID,
        mqtt_event_handler,
        NULL
    ));

    ESP_LOGI(TAG, "Iniciando MQTT ThingsBoard host=%s port=%d", THINGSBOARD_HOST, THINGSBOARD_PORT);

    return esp_mqtt_client_start(s_client);
}

bool mqtt_thingsboard_is_connected(void)
{
    return s_connected;
}

esp_err_t mqtt_thingsboard_publish_json(const char *json)
{
    if (json == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    if (s_client == NULL) {
        ESP_LOGW(TAG, "Cliente MQTT no inicializado");
        return ESP_ERR_INVALID_STATE;
    }

    if (!s_connected) {
        ESP_LOGW(TAG, "MQTT aun no conectado, no se publica");
        return ESP_ERR_INVALID_STATE;
    }

    int msg_id = esp_mqtt_client_publish(
        s_client,
        MQTT_TOPIC,
        json,
        0,
        0,
        0
    );

    if (msg_id < 0) {
        ESP_LOGE(TAG, "Fallo publicando JSON a ThingsBoard");
        return ESP_FAIL;
    }

    ESP_LOGI(TAG, "JSON publicado ThingsBoard msg_id=%d", msg_id);
    return ESP_OK;
}