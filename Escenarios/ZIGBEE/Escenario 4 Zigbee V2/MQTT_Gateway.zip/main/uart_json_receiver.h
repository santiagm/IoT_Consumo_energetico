#pragma once

#include "esp_err.h"

typedef void (*uart_json_cb_t)(const char *json);

esp_err_t uart_json_receiver_start(uart_json_cb_t cb);