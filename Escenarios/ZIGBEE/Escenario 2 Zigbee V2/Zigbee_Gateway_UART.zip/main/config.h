#pragma once
#include "driver/gpio.h"

#define ZIGBEE_PAN_ID                0x1234
#define ZIGBEE_CHANNEL               25
#define ZIGBEE_PRIMARY_CHANNEL_MASK      (1UL << ZIGBEE_CHANNEL)
#define ZIGBEE_ENDPOINT_NODE         10
#define ZIGBEE_ENDPOINT_GATEWAY      1
#define ZIGBEE_CUSTOM_CLUSTER_ID     0xFF00
#define ZIGBEE_CUSTOM_COMMAND_ID     0x01
#define ZIGBEE_PERMIT_JOIN_SECONDS   60

#define UART_BRIDGE_PORT             UART_NUM_1
#define UART_BRIDGE_TX_GPIO          GPIO_NUM_4
#define UART_BRIDGE_RX_GPIO          GPIO_NUM_5
#define UART_BRIDGE_BAUD             115200
