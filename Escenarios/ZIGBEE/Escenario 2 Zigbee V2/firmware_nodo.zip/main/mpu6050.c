#include <string.h>
#include "esp_log.h"
#include "esp_check.h"
#include "driver/i2c_master.h"
#include "driver/gpio.h"
#include "driver/rtc_io.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "config.h"
#include "mpu6050.h"

static const char *TAG = "MPU6050";
static i2c_master_bus_handle_t s_bus = NULL;
static i2c_master_dev_handle_t s_dev = NULL;

#define MPU6050_REG_SMPLRT_DIV   0x19
#define MPU6050_REG_CONFIG       0x1A
#define MPU6050_REG_GYRO_CONFIG  0x1B
#define MPU6050_REG_ACCEL_CONFIG 0x1C
#define MPU6050_REG_FIFO_EN      0x23
#define MPU6050_REG_INT_ENABLE   0x38
#define MPU6050_REG_INT_STATUS   0x3A
#define MPU6050_REG_ACCEL_XOUT_H 0x3B
#define MPU6050_REG_USER_CTRL    0x6A
#define MPU6050_REG_PWR_MGMT_1   0x6B
#define MPU6050_REG_PWR_MGMT_2   0x6C

#define MPU6050_USER_CTRL_FIFO_RESET_BIT 0x04

static esp_err_t mpu6050_write_reg(uint8_t reg, uint8_t val)
{
    if (!s_dev) {
        return ESP_ERR_INVALID_STATE;
    }
    uint8_t data[2] = {reg, val};
    return i2c_master_transmit(s_dev, data, sizeof(data), pdMS_TO_TICKS(100));
}

static esp_err_t mpu6050_read_regs(uint8_t reg, uint8_t *buf, size_t len)
{
    if (!s_dev || !buf || len == 0) {
        return ESP_ERR_INVALID_ARG;
    }
    return i2c_master_transmit_receive(s_dev, &reg, 1, buf, len, pdMS_TO_TICKS(100));
}

static void mpu6050_release_i2c_bus(void)
{
    if (s_dev) {
        esp_err_t err = i2c_master_bus_rm_device(s_dev);
        if (err != ESP_OK) {
            ESP_LOGW(TAG, "No se pudo remover dispositivo I2C MPU6050: %s", esp_err_to_name(err));
        }
        s_dev = NULL;
    }

    if (s_bus) {
        esp_err_t err = i2c_del_master_bus(s_bus);
        if (err != ESP_OK) {
            ESP_LOGW(TAG, "No se pudo liberar bus I2C: %s", esp_err_to_name(err));
        }
        s_bus = NULL;
    }
}

static void mpu6050_configure_sleep_gpios(void)
{
    ESP_LOGW(TAG, "Configurando SDA=GPIO%d, SCL=GPIO%d e INT=GPIO%d como entrada flotante",
             I2C_SDA_GPIO, I2C_SCL_GPIO, MPU6050_INT_GPIO);

    const gpio_num_t pins[] = { I2C_SDA_GPIO, I2C_SCL_GPIO, MPU6050_INT_GPIO };

    for (size_t i = 0; i < sizeof(pins) / sizeof(pins[0]); i++) {
        rtc_gpio_deinit(pins[i]);
        gpio_reset_pin(pins[i]);
        gpio_set_direction(pins[i], GPIO_MODE_INPUT);
        gpio_set_pull_mode(pins[i], GPIO_FLOATING);
    }
}

esp_err_t mpu6050_init_sensor(void)
{
    i2c_master_bus_config_t bus_cfg = {
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .i2c_port = I2C_NUM_0,
        .sda_io_num = I2C_SDA_GPIO,
        .scl_io_num = I2C_SCL_GPIO,
        .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = true,
    };
    ESP_RETURN_ON_ERROR(i2c_new_master_bus(&bus_cfg, &s_bus), TAG, "i2c_new_master_bus");

    i2c_device_config_t dev_cfg = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address = MPU6050_I2C_ADDR,
        .scl_speed_hz = 400000,
    };
    ESP_RETURN_ON_ERROR(i2c_master_bus_add_device(s_bus, &dev_cfg, &s_dev), TAG, "i2c_master_bus_add_device");

    ESP_RETURN_ON_ERROR(mpu6050_write_reg(MPU6050_REG_PWR_MGMT_1, 0x00), TAG, "wake MPU6050");
    vTaskDelay(pdMS_TO_TICKS(5));
    ESP_LOGW(TAG, "MPU6050 inicializado correctamente");
    return ESP_OK;
}

esp_err_t mpu6050_read_10_samples(mpu_sample_t samples[STREAM_SAMPLE_COUNT])
{
    if (!samples) return ESP_ERR_INVALID_ARG;

    for (int i = 0; i < STREAM_SAMPLE_COUNT; i++) {
        uint8_t raw[14] = {0};
        esp_err_t err = mpu6050_read_regs(MPU6050_REG_ACCEL_XOUT_H, raw, sizeof(raw));
        if (err != ESP_OK) return err;

        samples[i].ax = (int16_t)((raw[0] << 8) | raw[1]);
        samples[i].ay = (int16_t)((raw[2] << 8) | raw[3]);
        samples[i].az = (int16_t)((raw[4] << 8) | raw[5]);
        samples[i].gx = (int16_t)((raw[8] << 8) | raw[9]);
        samples[i].gy = (int16_t)((raw[10] << 8) | raw[11]);
        samples[i].gz = (int16_t)((raw[12] << 8) | raw[13]);

        ESP_LOGI(TAG,
                 "MPU muestra %d raw ax=%d ay=%d az=%d gx=%d gy=%d gz=%d",
                 i,
                 samples[i].ax, samples[i].ay, samples[i].az,
                 samples[i].gx, samples[i].gy, samples[i].gz);

        if (i < STREAM_SAMPLE_COUNT - 1) {
            vTaskDelay(pdMS_TO_TICKS(STREAM_SAMPLE_DELAY_MS));
        }
    }

    ESP_LOGW(TAG, "MPU6050 OK, muestras crudas leidas=%u", (unsigned)STREAM_SAMPLE_COUNT);
    return ESP_OK;
}

esp_err_t mpu6050_sleep_deep(void)
{
    uint8_t int_status = 0x00;
    uint8_t pwr_mgmt_1 = 0xFF;
    uint8_t pwr_mgmt_2 = 0xFF;

    if (!s_dev) {
        ESP_LOGW(TAG, "mpu6050_sleep_deep(): MPU6050/I2C no inicializado; solo se liberan GPIOs");
        mpu6050_release_i2c_bus();
        mpu6050_configure_sleep_gpios();
        return ESP_OK;
    }

    ESP_LOGW(TAG, "Apagado profundo del MPU6050 antes del deep sleep del ESP32-C6");

    /* 1. Deshabilitar interrupciones del MPU6050. */
    esp_err_t err = mpu6050_write_reg(MPU6050_REG_INT_ENABLE, 0x00);
    if (err != ESP_OK) ESP_LOGW(TAG, "No se pudo deshabilitar INT_ENABLE: %s", esp_err_to_name(err));

    /* 2. Deshabilitar FIFO. */
    err = mpu6050_write_reg(MPU6050_REG_FIFO_EN, 0x00);
    if (err != ESP_OK) ESP_LOGW(TAG, "No se pudo deshabilitar FIFO_EN: %s", esp_err_to_name(err));

    /* 3. Resetear FIFO. */
    err = mpu6050_write_reg(MPU6050_REG_USER_CTRL, MPU6050_USER_CTRL_FIFO_RESET_BIT);
    if (err != ESP_OK) ESP_LOGW(TAG, "No se pudo resetear FIFO: %s", esp_err_to_name(err));
    vTaskDelay(pdMS_TO_TICKS(5));
    err = mpu6050_write_reg(MPU6050_REG_USER_CTRL, 0x00);
    if (err != ESP_OK) ESP_LOGW(TAG, "No se pudo limpiar USER_CTRL despues del reset FIFO: %s", esp_err_to_name(err));

    /* 4. Limpiar interrupciones pendientes leyendo INT_STATUS. */
    err = mpu6050_read_regs(MPU6050_REG_INT_STATUS, &int_status, 1);
    if (err == ESP_OK) {
        ESP_LOGI(TAG, "INT_STATUS leido para limpiar interrupciones pendientes = 0x%02X", int_status);
    } else {
        ESP_LOGW(TAG, "No se pudo leer INT_STATUS: %s", esp_err_to_name(err));
    }

    /* 5. Standby para acelerometro X/Y/Z y giroscopio X/Y/Z. */
    mpu6050_write_reg(MPU6050_REG_PWR_MGMT_2, 0x3F);

    /* 6. Activar SLEEP. */
    mpu6050_write_reg(MPU6050_REG_PWR_MGMT_1, 0x40);
    vTaskDelay(pdMS_TO_TICKS(5));

    /* 7 y 8. Verificar PWR_MGMT_1 y PWR_MGMT_2 con logs. */
    err = mpu6050_read_regs(MPU6050_REG_PWR_MGMT_1, &pwr_mgmt_1, 1);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "No se pudo leer PWR_MGMT_1: %s", esp_err_to_name(err));
    }

    err = mpu6050_read_regs(MPU6050_REG_PWR_MGMT_2, &pwr_mgmt_2, 1);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "No se pudo leer PWR_MGMT_2: %s", esp_err_to_name(err));
    }

    ESP_LOGW(TAG, "Verificacion MPU6050 sleep: PWR_MGMT_1=0x%02X PWR_MGMT_2=0x%02X",
             pwr_mgmt_1, pwr_mgmt_2);

    /* 9. Liberar bus I2C. */
    mpu6050_release_i2c_bus();
    ESP_LOGW(TAG, "Bus I2C liberado antes del deep sleep");

    /* 10. Dejar SDA/SCL/INT como entradas flotantes. */
    mpu6050_configure_sleep_gpios();

    return ESP_OK;
}

esp_err_t mpu6050_prepare_low_power(void)
{
    return mpu6050_sleep_deep();
}

void mpu6050_bus_delete(void)
{
    mpu6050_release_i2c_bus();
}

void mpu6050_disable_sensor_gpios(void)
{
    mpu6050_configure_sleep_gpios();
}
