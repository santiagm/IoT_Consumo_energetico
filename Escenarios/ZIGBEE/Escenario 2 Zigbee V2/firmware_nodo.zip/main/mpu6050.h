#pragma once
#include "esp_err.h"
#include "telemetry_packet.h"

esp_err_t mpu6050_init_sensor(void);
esp_err_t mpu6050_read_10_samples(mpu_sample_t samples[STREAM_SAMPLE_COUNT]);
esp_err_t mpu6050_sleep_deep(void);
esp_err_t mpu6050_prepare_low_power(void);
void mpu6050_bus_delete(void);
void mpu6050_disable_sensor_gpios(void);
