#pragma once

#define ZIGBEE_PAN_ID                0x1234
#define ZIGBEE_CHANNEL               25
#define ZIGBEE_PRIMARY_CHANNEL_MASK      (1UL << ZIGBEE_CHANNEL)
#define ZIGBEE_ENDPOINT_NODE         10 
#define ZIGBEE_ENDPOINT_GATEWAY      1
#define ZIGBEE_CUSTOM_CLUSTER_ID     0xFF00
#define ZIGBEE_CUSTOM_COMMAND_ID     0x01
#define ZIGBEE_TX_POWER_DBM          5

/* Optimización de tiempos activos del nodo Zigbee */
#define NODE_DEBUG_LOGS              0
#define ZIGBEE_JOIN_POLL_MS          5
#define POST_ZIGBEE_TX_DELAY_MS      10

#define NODE_SLEEP_TIME_US           (5ULL * 1000000ULL)

#ifndef ZIGBEE_ED_KEEPALIVE_MS
#define ZIGBEE_ED_KEEPALIVE_MS         3000
#endif
